package com.example.customer_api.entity;

// Enum for status
public enum CustomerStatus {
    ACTIVE,
    INACTIVE
}

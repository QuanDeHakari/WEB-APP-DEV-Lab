package com.example.product_management.controller;

import com.example.product_management.entity.Product;
import com.example.product_management.service.ProductService;

import java.math.BigDecimal;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
@Controller
@RequestMapping("/dashboard")
public class DashboardController {
    
    @Autowired
    private ProductService productService;
    
    @GetMapping
    public String showDashboard(Model model) {
        long totalProducts = productService.getAllProducts().size();

        List<String> categories = productService.getAllCategories();
        Map<String, Long> productsByCategory = new LinkedHashMap<>();
        for (String cat : categories) {
            productsByCategory.put(cat, productService.countByCategory(cat));
        }

        BigDecimal totalValue = productService.calculateTotalValue();
        BigDecimal avgPrice = productService.calculateAveragePrice();

        List<Product> lowStock = productService.findLowStockProducts(10);

        List<Product> recentProducts = productService.findRecentProducts(5);

        model.addAttribute("totalProducts", totalProducts);
        model.addAttribute("productsByCategory", productsByCategory);
        model.addAttribute("totalValue", totalValue);
        model.addAttribute("avgPrice", avgPrice);
        model.addAttribute("lowStockProducts", lowStock);
        model.addAttribute("recentProducts", recentProducts);

        return "dashboard";
    }
}
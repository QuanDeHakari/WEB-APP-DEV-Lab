package com.example.product_management.controller;

import com.example.product_management.entity.Product;
import com.example.product_management.service.ProductService;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.io.IOException;
import java.util.List;

@Controller
@RequestMapping("/export")
public class ExportController {

    @Autowired
    private ProductService productService;

    @GetMapping("/excel")
    public void exportToExcel(HttpServletResponse response) throws IOException {

        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        String fileName = "products.xlsx";
        response.setHeader("Content-Disposition", "attachment; filename=" + fileName);

        List<Product> products = productService.getAllProducts();

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Products");

            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("ID");
            header.createCell(1).setCellValue("Code");
            header.createCell(2).setCellValue("Name");
            header.createCell(3).setCellValue("Price");
            header.createCell(4).setCellValue("Quantity");
            header.createCell(5).setCellValue("Category");
            header.createCell(6).setCellValue("Description");
            header.createCell(7).setCellValue("Created At");

            int rowIdx = 1;
            for (Product p : products) {
                Row row = sheet.createRow(rowIdx++);
                row.createCell(0).setCellValue(p.getId());
                row.createCell(1).setCellValue(p.getProductCode());
                row.createCell(2).setCellValue(p.getName());
                row.createCell(3).setCellValue(
                        p.getPrice() != null ? p.getPrice().doubleValue() : 0.0);
                row.createCell(4).setCellValue(
                        p.getQuantity() != null ? p.getQuantity() : 0);
                row.createCell(5).setCellValue(p.getCategory());
                row.createCell(6).setCellValue(p.getDescription());
                row.createCell(7).setCellValue(
                        p.getCreatedAt() != null ? p.getCreatedAt().toString() : "");
            }

            for (int i = 0; i <= 7; i++) {
                sheet.autoSizeColumn(i);
            }

            workbook.write(response.getOutputStream());
        }
    }
}
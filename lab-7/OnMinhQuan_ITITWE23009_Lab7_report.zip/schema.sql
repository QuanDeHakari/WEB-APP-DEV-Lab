DROP DATABASE IF EXISTS product_management;
CREATE DATABASE product_management;
USE product_management;

CREATE TABLE products (
    id BIGINT PRIMARY KEY AUTO_INCREMENT,
    product_code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    quantity INT DEFAULT 0,
    category VARCHAR(50),
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data
INSERT INTO products (product_code, name, price, quantity, category, description) VALUES
('P001', 'Laptop Dell XPS 13', 1299.99, 10, 'Electronics', 'High-performance laptop'),
('P002', 'iPhone 15 Pro', 999.99, 25, 'Electronics', 'Latest iPhone model'),
('P003', 'Office Chair', 199.99, 50, 'Furniture', 'Ergonomic office chair'),
('P004', 'Samsung Galaxy S24', 899.99, 30, 'Electronics', 'Flagship Android smartphone'),
('P005', 'Sony WH-1000XM5', 349.99, 40, 'Electronics', 'Noise-cancelling headphones'),
('P006', 'Mechanical Keyboard', 129.99, 60, 'Electronics', 'RGB mechanical keyboard'),
('P007', '4K Monitor 27 inch', 399.99, 20, 'Electronics', 'Ultra HD IPS monitor'),
('P008', 'Gaming Mouse', 59.99, 80, 'Electronics', 'High DPI gaming mouse'),
('P009', 'Bluetooth Speaker', 79.99, 70, 'Electronics', 'Portable wireless speaker'),
('P010', 'Smartwatch Garmin', 249.99, 35, 'Electronics', 'Fitness tracking smartwatch'),

('P011', 'Wooden Dining Table', 499.99, 15, 'Furniture', 'Solid wood dining table'),
('P012', 'Bookshelf 5-Tier', 149.99, 25, 'Furniture', 'Modern wooden bookshelf'),
('P013', 'Sofa 3 Seater', 799.99, 8, 'Furniture', 'Comfortable fabric sofa'),
('P014', 'Bed Frame Queen', 399.99, 12, 'Furniture', 'Queen size bed frame'),
('P015', 'Coffee Table', 129.99, 30, 'Furniture', 'Glass top coffee table'),

('P016', 'Running Shoes Nike', 119.99, 45, 'Clothing', 'Lightweight running shoes'),
('P017', 'Hoodie Unisex', 49.99, 100, 'Clothing', 'Cotton fleece hoodie'),
('P018', 'Jeans Slim Fit', 59.99, 90, 'Clothing', 'Blue slim-fit jeans'),
('P019', 'T-Shirt Basic', 19.99, 150, 'Clothing', 'Basic cotton t-shirt'),
('P020', 'Jacket Windbreaker', 89.99, 35, 'Clothing', 'Water-resistant jacket'),

('P021', 'Cookware Set 10pc', 179.99, 20, 'Home', 'Non-stick cookware set'),
('P022', 'Vacuum Cleaner', 229.99, 18, 'Home', 'Bagless vacuum cleaner'),
('P023', 'Air Fryer', 149.99, 22, 'Home', 'Digital air fryer'),
('P024', 'Electric Kettle', 39.99, 60, 'Home', 'Stainless steel kettle'),
('P025', 'Blender 1.5L', 69.99, 40, 'Home', 'Multi-speed blender'),

('P026', 'USB-C Cable 1m', 9.99, 200, 'Accessories', 'Fast charging USB-C cable'),
('P027', 'Laptop Sleeve 13"', 24.99, 75, 'Accessories', 'Protective laptop sleeve'),
('P028', 'Wireless Charger', 29.99, 50, 'Accessories', 'Qi wireless charging pad'),
('P029', 'Backpack Travel', 89.99, 30, 'Accessories', 'Waterproof travel backpack'),
('P030', 'Power Bank 20000mAh', 49.99, 65, 'Accessories', 'High capacity power bank');
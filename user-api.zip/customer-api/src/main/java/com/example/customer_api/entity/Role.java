package com.example.customer_api.entity;

public enum Role {
    USER,
    ADMIN
}